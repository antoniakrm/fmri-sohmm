./run_fmri.sh baseline;

./run_fmri.sh token;
